# DesignSupportLibraryDemo
Android Design Support Library Demo

## You can see the details in here:

http://blog.csdn.net/eclipsexys/article/details/46349721

![](https://github.com/xuyisheng/DesignSupportLibraryDemo/blob/master/gif/6%E6%9C%88%2004%2C%202015%2022:57.gif)
![](https://github.com/xuyisheng/DesignSupportLibraryDemo/blob/master/gif/6%E6%9C%88%2004%2C%202015%2022:58.gif)
